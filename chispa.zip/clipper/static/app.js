const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
let tab = 'url', file = null, pollTimer = null, currentJob = null, lastRenderKey = '';

const STEPS = [
  ['downloading', 'Descarga'], ['analyzing', 'Análisis'], ['transcribing', 'Transcripción'],
  ['scoring', 'Momentos clave'], ['rendering', 'Exportación'], ['done', 'Listo']];
const BD_LABELS = {hook: 'Gancho', energy: 'Energía', keywords: 'Palabras clave', density: 'Ritmo', emotion: 'Emoción', coherence: 'Coherencia', length: 'Duración'};

const fmtTime = s => { s = Math.max(0, s); const m = Math.floor(s / 60), r = Math.floor(s % 60); return `${m}:${String(r).padStart(2, '0')}`; };
const fmtSize = b => b > 1e9 ? (b / 1e9).toFixed(2) + ' GB' : (b / 1e6).toFixed(1) + ' MB';
const esc = t => String(t ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));

// ---- tabs / file input
$$('.tab').forEach(b => b.onclick = () => {
  tab = b.dataset.tab;
  $$('.tab').forEach(x => x.classList.toggle('active', x === b));
  $$('.pane').forEach(p => p.classList.toggle('hidden', p.dataset.pane !== tab));
});
const setFile = f => { file = f; $('#fileName').textContent = f ? `${f.name} · ${fmtSize(f.size)}` : 'MP4, MOV, MKV, WEBM…'; };
$('#file').onchange = e => setFile(e.target.files[0]);
const drop = $('#drop');
['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
drop.addEventListener('drop', e => { if (e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]); });

function showErr(msg) { const el = $('#formErr'); el.textContent = msg; el.classList.toggle('hidden', !msg); }

// ---- create job
$('#form').onsubmit = e => {
  e.preventDefault(); showErr('');
  const fd = new FormData();
  if (tab === 'url') {
    const u = $('#url').value.trim();
    if (!u) return showErr('Pega el enlace de un video.');
    fd.append('url', u);
  } else {
    if (!file) return showErr('Elige un archivo de video.');
    fd.append('file', file);
  }
  const fmts = $$('input[name=fmt]:checked').map(i => i.value);
  if (!fmts.length) return showErr('Elige al menos un formato.');
  const [mn, mx] = $('#lenRange').value.split('-');
  fd.append('formats', fmts.join(','));
  fd.append('captions', $('#captions').checked);
  fd.append('num_clips', $('#numClips').value);
  fd.append('min_len', mn); fd.append('max_len', mx);
  fd.append('language', $('#language').value);
  fd.append('upscale', $('#upscale').checked);

  const btn = $('#submit'); btn.disabled = true; btn.textContent = tab === 'file' ? 'Subiendo video…' : 'Creando proyecto…';
  const bar = $('#uploadBar');
  const done = () => { btn.disabled = false; btn.textContent = '⚡ Generar clips'; bar.classList.add('hidden'); };
  (async () => {
    try {
      if (tab === 'file') {
        bar.classList.remove('hidden');
        const uid = await chunkedUpload(file, p => { bar.firstElementChild.style.width = p + '%'; bar.lastElementChild.textContent = p.toFixed(0) + '%'; });
        fd.delete('file'); fd.append('upload_id', uid);
        btn.textContent = 'Creando proyecto…';
      }
      const r = await fetch('/api/jobs', {method: 'POST', body: fd});
      if (r.status === 401) { location.href = '/login'; return; }
      const data = await r.json().catch(() => ({}));
      done();
      if (!r.ok) return showErr(data.detail || 'Error al crear el proyecto.');
      $('#url').value = ''; setFile(null);
      location.hash = 'job/' + data.id;
    } catch (err) { done(); showErr(err.message || 'No se pudo conectar con el servidor.'); }
  })();
};

// Upload in ~50 MB pieces so large files pass through proxies/tunnels with per-request limits.
function putChunk(url, blob, onProg) {
  return new Promise((res, rej) => {
    const x = new XMLHttpRequest(); x.open('PUT', url);
    x.upload.onprogress = e => e.lengthComputable && onProg(e.loaded);
    x.onload = () => x.status === 401 ? (location.href = '/login') : x.status < 300 ? res() : rej(new Error('Error al subir (' + x.status + ')'));
    x.onerror = () => rej(new Error('Conexión interrumpida al subir'));
    x.send(blob);
  });
}
async function chunkedUpload(f, onPct) {
  const init = new FormData(); init.append('filename', f.name); init.append('size', f.size);
  const r = await fetch('/api/uploads', {method: 'POST', body: init});
  if (r.status === 401) { location.href = '/login'; throw new Error('Sesión expirada'); }
  if (!r.ok) throw new Error('No se pudo iniciar la subida');
  const {upload_id, chunk_size} = await r.json();
  for (let off = 0; off < f.size; off += chunk_size) {
    const blob = f.slice(off, off + chunk_size);
    for (let attempt = 0; ; attempt++) {
      try { await putChunk(`/api/uploads/${upload_id}?offset=${off}`, blob, l => onPct((off + l) / f.size * 100)); break; }
      catch (e) { if (attempt >= 3) throw e; await new Promise(z => setTimeout(z, 1500 * (attempt + 1))); }
    }
  }
  onPct(100);
  return upload_id;
}

// ---- routing
function route() {
  const m = location.hash.match(/^#job\/(\w+)/);
  clearTimeout(pollTimer);
  if (m) { $('#hero').classList.add('hidden'); $('#jobView').classList.remove('hidden'); lastRenderKey = ''; $('#clips').innerHTML = ''; loadJob(m[1]); }
  else { $('#hero').classList.remove('hidden'); $('#jobView').classList.add('hidden'); currentJob = null; }
  loadProjects();
}
window.addEventListener('hashchange', route);
$('#backBtn').onclick = () => { location.hash = ''; };
$('#homeLink').onclick = e => { e.preventDefault(); location.hash = ''; };
$('#navProjects').onclick = e => { e.preventDefault(); $('#projects').scrollIntoView({behavior: 'smooth'}); };

async function loadProjects() {
  try {
    const jobs = await (await fetch('/api/jobs')).json();
    const el = $('#projectList');
    if (!jobs.length) { el.innerHTML = '<div class="muted">Aún no hay proyectos.</div>'; return; }
    el.innerHTML = jobs.map(j => {
      const cls = j.status === 'done' ? 'done' : j.status === 'error' ? 'error' : 'run';
      const lbl = j.status === 'done' ? `✓ ${j.n_clips} clips` : j.status === 'error' ? 'Error' : `${Math.round(j.progress)}%`;
      return `<div class="proj" data-id="${j.id}"><div class="t">${esc(j.title)}</div>
        <div class="muted">${new Date(j.created_at * 1000).toLocaleString('es')} · <span class="badge ${cls}">${lbl}</span></div></div>`;
    }).join('');
    $$('.proj').forEach(p => p.onclick = () => { location.hash = 'job/' + p.dataset.id; window.scrollTo({top: 0}); });
  } catch {}
}

async function loadJob(id) {
  let job;
  try {
    const r = await fetch('/api/jobs/' + id);
    if (r.status === 401) { location.href = '/login'; return; }
    if (!r.ok) { $('#jobTitle').textContent = 'Proyecto no encontrado'; return; }
    job = await r.json();
  } catch { pollTimer = setTimeout(() => loadJob(id), 2000); return; }
  currentJob = job;
  renderJob(job);
  if (!['done', 'error'].includes(job.status)) pollTimer = setTimeout(() => loadJob(id), 1500);
  else loadProjects();
}

function renderJob(job) {
  $('#jobTitle').textContent = job.title || 'Video';
  const m = job.media;
  $('#jobMeta').textContent = [
    m ? `${m.width}×${m.height} · ${fmtTime(m.duration)} · ${m.fps} fps` : null,
    job.language ? `Idioma: ${job.language}` : null,
    job.source.type === 'url' ? job.source.url : job.source.original_name].filter(Boolean).join(' · ');
  $('#jobActions').innerHTML = job.status === 'done'
    ? `<a class="ghost" href="/media/${job.id}/transcript.srt?download=1">📝 Transcripción completa (SRT)</a>
       <button class="ghost" id="delBtn">🗑 Borrar</button>` : (job.status === 'error' ? `<button class="ghost" id="delBtn">🗑 Borrar</button>` : '');
  const del = $('#delBtn');
  if (del) del.onclick = async () => { if (confirm('¿Borrar este proyecto y sus clips?')) { await fetch('/api/jobs/' + job.id, {method: 'DELETE'}); location.hash = ''; } };

  // status
  const card = $('#statusCard');
  card.classList.toggle('error', job.status === 'error');
  card.classList.toggle('done', job.status === 'done');
  const order = STEPS.map(s => s[0]);
  let cur = order.indexOf(job.status);
  if (job.status === 'queued') cur = -1;
  $('#steps').innerHTML = STEPS.filter(s => !(s[0] === 'downloading' && job.source.type !== 'url'))
    .map(([k, l]) => { const i = order.indexOf(k); const c = job.status === 'done' || i < cur ? 'done' : i === cur ? 'active' : ''; return `<span class="step ${c}">${c === 'done' ? '✓ ' : ''}${l}</span>`; }).join('');
  $('#bar').style.width = job.progress + '%';
  $('#notice').textContent = job.notice || ''; $('#notice').classList.toggle('hidden', !job.notice);
  $('#statusMsg').textContent = (job.status === 'error' ? '⚠️ ' : '') + (job.message || '');

  // re-render panel
  const rr = $('#rerenderCard');
  rr.classList.toggle('hidden', !(job.status === 'done' && job.clips.length));
  if (job.status === 'done') {
    $$('input[name=rfmt]').forEach(i => i.checked = (job.options.formats || []).includes(i.value));
    $('#rCaptions').checked = !!job.options.captions;
  }

  // clips (re-render DOM only when something changed, so videos don't reload while polling)
  const key = JSON.stringify(job.clips.map(c => [c.index, Object.values(c.renders || {}).map(r => r.v + r.file)]));
  if (key === lastRenderKey) return;
  lastRenderKey = key;
  $('#clips').innerHTML = job.clips.map(c => clipHTML(job, c)).join('');
  $$('.cap-toggle').forEach(inp => inp.onchange = async () => {
    const fd = new FormData(); fd.append('captions', inp.checked);
    const r = await fetch(`/api/jobs/${job.id}/clips/${inp.dataset.idx}/rerender`, {method: 'POST', body: fd});
    if (r.ok) { lastRenderKey = ''; loadJob(job.id); } else { inp.checked = !inp.checked; alert((await r.json()).detail || 'Error'); }
  });
}

function clipHTML(job, c) {
  const r = c.renders || {};
  const vid = (fmt, cls) => {
    const x = r[fmt];
    if (!x) return (job.options.formats || []).includes(fmt) && job.status !== 'done' && job.status !== 'error'
      ? `<div class="vid ${cls}"><span class="fmt">${fmt === 'vertical' ? 'Vertical 9:16' : 'Horizontal 16:9'}</span><video poster="" style="opacity:.3"></video><span class="muted">Exportando…</span></div>` : '';
    const src = `/media/${job.id}/${x.file}?v=${x.v}`;
    return `<div class="vid ${cls}"><span class="fmt">${esc(x.label)} · ${x.width}×${x.height}</span>
      <video controls preload="metadata" playsinline poster="/media/${job.id}/${x.thumb}?v=${x.v}" src="${src}"></video>
      <a class="dl" href="/media/${job.id}/${x.file}?download=1">⬇ Descargar ${fmt === 'vertical' ? '9:16' : '16:9'} · ${x.height}p · ${fmtSize(x.size)}</a></div>`;
  };
  const anyCap = Object.values(r).some(x => x.captions);
  const bd = Object.entries(c.breakdown || {}).map(([k, v]) => `<div>${BD_LABELS[k] || k}<i><b style="width:${Math.round(v * 100)}%"></b></i></div>`).join('');
  return `<div class="card clip">
    <div class="vids">${vid('vertical', 'v')}${vid('horizontal', 'h')}</div>
    <div class="clip-info">
      <div class="score">${c.score}<small>/100 potencial viral</small></div>
      <h3>#${c.index} · ${esc(c.title)}</h3>
      <div class="meta"><span class="pill">⏱ ${fmtTime(c.start)} – ${fmtTime(c.end)}</span><span class="pill">${c.duration}s</span>${anyCap ? '<span class="pill">💬 con subtítulos</span>' : ''}</div>
      <div class="bd">${bd}</div>
      ${c.text ? `<div class="transcript">${esc(c.text)}</div>` : ''}
      <div class="clip-actions">
        <a class="ghost" href="/media/${job.id}/${c.srt}?download=1">📝 Descargar SRT</a>
        ${job.status === 'done' ? `<label class="switch"><input type="checkbox" class="cap-toggle" data-idx="${c.index}" ${anyCap ? 'checked' : ''}><span></span> Subtítulos incrustados en este clip</label>` : ''}
      </div>
    </div></div>`;
}

$('#rerenderBtn').onclick = async () => {
  if (!currentJob) return;
  const fmts = $$('input[name=rfmt]:checked').map(i => i.value);
  if (!fmts.length) return alert('Elige al menos un formato.');
  const fd = new FormData(); fd.append('formats', fmts.join(',')); fd.append('captions', $('#rCaptions').checked);
  fd.append('upscale', currentJob.options.upscale);
  const r = await fetch(`/api/jobs/${currentJob.id}/rerender`, {method: 'POST', body: fd});
  if (r.ok) { lastRenderKey = ''; loadJob(currentJob.id); } else alert((await r.json()).detail || 'Error');
};

route();
