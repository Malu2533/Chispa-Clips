"""Job pipeline: acquire -> probe -> audio/RMS -> transcribe -> score -> render."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import threading
import time
import traceback
import wave
from pathlib import Path

import numpy as np

from . import captions, scoring

DATA = Path(os.environ.get("CLIPPER_DATA", Path(__file__).resolve().parent.parent / "data")) / "jobs"
DATA.mkdir(parents=True, exist_ok=True)
MODEL_NAME = os.environ.get("CLIPPER_MODEL", "small")
CRF = os.environ.get("CLIPPER_CRF", "18")
PRESET = os.environ.get("CLIPPER_PRESET", "fast")
MAX_HEIGHT = int(os.environ.get("CLIPPER_MAX_HEIGHT", "1080"))

FORMATS = {
    "vertical": {"label": "Vertical 9:16", "short": "9x16"},
    "horizontal": {"label": "Horizontal 16:9", "short": "16x9"},
}

JOBS: dict[str, dict] = {}
LOCK = threading.Lock()
_model = None
_model_lock = threading.Lock()


# ---------------------------------------------------------------- job state
def job_dir(job_id: str) -> Path:
    return DATA / job_id


def save(job: dict):
    d = job_dir(job["id"])
    d.mkdir(parents=True, exist_ok=True)
    tmp = d / "job.json.tmp"
    tmp.write_text(json.dumps(job, ensure_ascii=False, indent=1))
    tmp.replace(d / "job.json")


def update(job: dict, **kw):
    with LOCK:
        job.update(kw)
        job["updated_at"] = time.time()
        save(job)


def load_existing():
    for p in sorted(DATA.glob("*/job.json")):
        try:
            job = json.loads(p.read_text())
        except Exception:
            continue
        if job.get("status") not in ("done", "error"):
            job["status"] = "error"
            job["message"] = "El servidor se reinició mientras se procesaba este trabajo."
        JOBS[job["id"]] = job


def public(job: dict) -> dict:
    j = {k: v for k, v in job.items() if k not in ("segments",)}
    j["clips"] = [{k: v for k, v in c.items() if k != "words"} for c in job.get("clips", [])]
    return j


# ---------------------------------------------------------------- helpers
def run(cmd, cwd=None):
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError(f"{cmd[0]} falló: {p.stderr[-1500:]}")
    return p.stdout


def probe(path: Path) -> dict:
    out = json.loads(run(["ffprobe", "-v", "error", "-print_format", "json", "-show_streams", "-show_format", str(path)]))
    v = next((s for s in out["streams"] if s["codec_type"] == "video"), None)
    a = next((s for s in out["streams"] if s["codec_type"] == "audio"), None)
    if not v:
        raise RuntimeError("El archivo no contiene una pista de video.")
    w, h = int(v["width"]), int(v["height"])
    rot = 0
    for sd in v.get("side_data_list", []) or []:
        if "rotation" in sd:
            rot = abs(int(sd["rotation"]))
    if rot in (90, 270):
        w, h = h, w
    num, den = (v.get("avg_frame_rate") or "30/1").split("/")
    fps = float(num) / float(den) if float(den) else 30.0
    return {"width": w, "height": h, "fps": round(fps, 3), "duration": float(out["format"]["duration"]),
            "has_audio": a is not None, "vcodec": v.get("codec_name")}


def get_model():
    global _model
    with _model_lock:
        if _model is None:
            from faster_whisper import WhisperModel
            _model = WhisperModel(MODEL_NAME, device="cpu", compute_type="int8", cpu_threads=os.cpu_count() or 4)
        return _model


def rms_function(wav_path: Path):
    with wave.open(str(wav_path)) as wf:
        sr = wf.getframerate()
        data = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
    hop = sr // 2  # 0.5 s windows
    n = max(1, len(data) // hop)
    frames = data[: n * hop].reshape(n, hop) if len(data) >= hop else data.reshape(1, -1)
    db = 20 * np.log10(np.sqrt((frames ** 2).mean(axis=1)) + 1e-6)

    def fn(t0, t1):
        a, b = int(t0 * 2), max(int(t0 * 2) + 1, int(t1 * 2))
        seg = db[a:b]
        return float(seg.mean()) if len(seg) else -60.0
    return fn


# ---------------------------------------------------------------- stages
def acquire(job: dict) -> Path:
    d = job_dir(job["id"])
    if job["source"]["type"] == "upload":
        return d / job["source"]["filename"]
    import yt_dlp

    update(job, status="downloading", message="Descargando video del enlace…", progress=2)

    def hook(st):
        if st.get("status") == "downloading":
            tot = st.get("total_bytes") or st.get("total_bytes_estimate") or 0
            if tot:
                pct = st.get("downloaded_bytes", 0) / tot
                update(job, progress=round(2 + 18 * pct, 1),
                       message=f"Descargando video… {pct*100:.0f}%")

    opts = {
        # best quality up to MAX_HEIGHT (1080p default; set CLIPPER_MAX_HEIGHT=2160 for 4K),
        # preferring direct https (DASH) streams over slower HLS fragments
        "format": (f"bv*[height<={MAX_HEIGHT}][protocol=https]+ba[protocol=https]/"
                   f"bv*[height<={MAX_HEIGHT}]+ba/b[height<={MAX_HEIGHT}]/bv*+ba/b"),
        "format_sort": ["res", "fps", "vcodec:avc1", "proto:https"],
        "concurrent_fragment_downloads": 8,
        "merge_output_format": "mkv",
        "outtmpl": str(d / "source.%(ext)s"),
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "progress_hooks": [hook],
        "js_runtimes": {"node": {}, "deno": {}},
        "retries": 3,
    }
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(job["source"]["url"], download=True)
    title = info.get("title") or "Video"
    files = [p for p in d.glob("source.*") if p.suffix not in (".part", ".ytdl", ".json")]
    if not files:
        raise RuntimeError("yt-dlp no produjo ningún archivo.")
    update(job, title=title)
    return files[0]


def transcribe(job: dict, wav: Path, duration: float) -> list[dict]:
    update(job, status="transcribing", message="Cargando modelo de transcripción…", progress=24)
    model = get_model()
    lang = job["options"].get("language") or None
    if lang == "auto":
        lang = None
    with wave.open(str(wav)) as wf:  # pass raw samples (avoids PyAV decoding issues)
        audio = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
    seg_iter, info = model.transcribe(audio, language=lang, word_timestamps=True, vad_filter=True, beam_size=1)
    update(job, language=info.language, message=f"Transcribiendo audio ({info.language})…")
    segs = []
    for s in seg_iter:
        segs.append({"start": round(s.start, 2), "end": round(s.end, 2), "text": s.text.strip(),
                     "words": [{"start": round(w.start, 2), "end": round(w.end, 2), "word": w.word.strip()} for w in (s.words or [])]})
        pct = min(1.0, s.end / max(1.0, duration))
        update(job, progress=round(25 + 40 * pct, 1), message=f"Transcribiendo audio… {pct*100:.0f}%")
    return segs


def _video_filter(fmt: str, src_w: int, src_h: int, upscale: bool):
    """Return (filter_chain, out_w, out_h)."""
    even = lambda x: int(x) // 2 * 2
    if fmt == "vertical":
        if src_w / src_h > 9 / 16:  # wider than 9:16 -> center crop
            cw, ch = even(src_h * 9 / 16), even(src_h)
            chain = f"crop={cw}:{ch}:(iw-{cw})/2:0"
        else:
            cw, ch = even(src_w), min(even(src_h), even(src_w * 16 / 9))
            chain = f"crop={cw}:{ch}:0:(ih-{ch})/2"
        if upscale and ch < 1920:
            return chain + ",scale=1080:1920:flags=lanczos,setsar=1", 1080, 1920
        return chain + ",setsar=1", cw, ch
    # horizontal
    if src_w / src_h >= 1.0:  # already landscape/square: keep original framing
        w, h = even(src_w), even(src_h)
        return f"scale={w}:{h},setsar=1", w, h
    # portrait source -> 16:9 with blurred background fill
    h = even(max(src_h, 720))
    h = min(h, 1080) if not upscale else max(1080, min(h, 2160))
    w = even(h * 16 / 9)
    chain = (f"split[a][b];[a]scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},boxblur=30:5[bg];"
             f"[b]scale=-2:{h}[fg];[bg][fg]overlay=(W-w)/2:0,setsar=1")
    return chain, w, h


def render_clip(job: dict, clip: dict, src: Path, fmt: str, burn: bool, upscale: bool):
    d = job_dir(job["id"])
    meta = job["media"]
    n = clip["index"]
    chain, ow, oh = _video_filter(fmt, meta["width"], meta["height"], upscale)
    base = f"clip_{n:02d}_{FORMATS[fmt]['short']}"
    if burn and clip.get("words"):
        ass = d / f"{base}.ass"
        ass.write_text(captions.build_ass(clip["words"], ow, oh, fmt == "vertical"), encoding="utf-8")
        chain += f",ass={ass.name}"
    out = d / f"{base}.mp4"
    dur = clip["end"] - clip["start"]
    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{clip['start']:.3f}", "-i", str(src),
           "-t", f"{dur:.3f}", "-filter_complex", f"[0:v]{chain}[v]", "-map", "[v]", "-map", "0:a?",
           "-c:v", "libx264", "-preset", PRESET, "-crf", CRF, "-profile:v", "high", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-movflags", "+faststart", out.name]
    run(cmd, cwd=d)
    thumb = d / f"{base}.jpg"
    run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{min(1.0, dur/2):.2f}", "-i", out.name,
         "-frames:v", "1", "-vf", "scale='min(640,iw)':-2", thumb.name], cwd=d)
    return {"format": fmt, "label": FORMATS[fmt]["label"], "file": out.name, "thumb": thumb.name,
            "width": ow, "height": oh, "size": out.stat().st_size, "captions": bool(burn and clip.get("words")), "v": int(time.time())}


def render_all(job: dict, src: Path, base_progress=72):
    opts = job["options"]
    fmts = [f for f in ("vertical", "horizontal") if f in opts.get("formats", ["vertical", "horizontal"])] or ["vertical", "horizontal"]
    total = len(job["clips"]) * len(fmts)
    done = 0
    for clip in job["clips"]:
        clip["renders"] = {}
        for fmt in fmts:
            update(job, status="rendering", progress=round(base_progress + (99 - base_progress) * done / total, 1),
                   message=f"Exportando clip {clip['index']} de {len(job['clips'])} · {FORMATS[fmt]['label']}…")
            clip["renders"][fmt] = render_clip(job, clip, src, fmt, opts.get("captions", False), opts.get("upscale", True))
            done += 1
            update(job, clips=job["clips"])


def process(job: dict):
    try:
        d = job_dir(job["id"])
        src = acquire(job)
        update(job, status="analyzing", message="Analizando video…", progress=20, source_file=src.name)
        media = probe(src)
        update(job, media=media)
        if not media["has_audio"]:
            raise RuntimeError("El video no tiene audio; se necesita audio para encontrar los mejores momentos.")
        wav = d / "audio.wav"
        run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(src), "-vn", "-ac", "1", "-ar", "16000", wav.name], cwd=d)
        rms = rms_function(wav)
        segs = transcribe(job, wav, media["duration"])
        (d / "transcript.json").write_text(json.dumps(segs, ensure_ascii=False))
        all_words = captions.words_in_range(segs, 0, media["duration"])
        (d / "transcript.srt").write_text(captions.build_srt(all_words), encoding="utf-8")

        update(job, status="scoring", message="Buscando los momentos más virales…", progress=68)
        o = job["options"]
        picks = scoring.select_clips(segs, media["duration"], rms, n_clips=int(o.get("num_clips", 7)),
                                     min_len=float(o.get("min_len", 60)), max_len=float(o.get("max_len", 80)))
        if not picks:
            raise RuntimeError("No se encontraron momentos aprovechables en el video.")
        clips = []
        for k, p in enumerate(picks, 1):
            words = captions.words_in_range(segs, p["start"], p["end"])
            srt_name = f"clip_{k:02d}.srt"
            (d / srt_name).write_text(captions.build_srt(words), encoding="utf-8")
            clips.append({"index": k, "start": round(p["start"], 2), "end": round(p["end"], 2),
                          "duration": round(p["end"] - p["start"], 1), "title": p["title"], "score": p["score"],
                          "breakdown": p["breakdown"], "text": p["text"], "srt": srt_name, "words": words})
        want = int(o.get("num_clips", 7))
        if len(clips) < want:
            mins = media["duration"] / 60
            n = len(clips)
            update(job, notice=(f"Se {'generó' if n == 1 else 'generaron'} {n} de {want} clips: el video dura {mins:.1f} min y solo "
                                f"{'cabe 1 momento' if n == 1 else f'caben {n} momentos'} de {o.get('min_len', 60):.0f}–{o.get('max_len', 80):.0f} s sin solaparse "
                                f"y que empiecen y terminen en una frase completa. Usa un video más largo o un rango de duración más corto para obtener más."))
        update(job, clips=clips, progress=72)
        render_all(job, src)
        update(job, status="done", progress=100, message=f"¡Listo! {len(clips)} {'clip generado' if len(clips) == 1 else 'clips generados'} en vertical y horizontal.", finished_at=time.time())
        try:
            wav.unlink()
        except Exception:
            pass
    except Exception as e:  # noqa
        traceback.print_exc()
        msg = str(e)
        low = msg.lower()
        if "sign in" in low or "bot" in low and "confirm" in low:
            msg = "El sitio bloqueó la descarga (pide iniciar sesión / verificación anti-bot). Descarga el video y súbelo como archivo. Detalle: " + msg[:300]
        elif "unsupported url" in low:
            msg = "Este enlace no es compatible. Prueba con otro sitio o sube el archivo directamente."
        update(job, status="error", message=msg[:800])


def rerender(job: dict, options: dict):
    try:
        job["options"].update(options)
        src = job_dir(job["id"]) / job["source_file"]
        update(job, status="rendering", progress=5, message="Re-exportando clips…")
        render_all(job, src, base_progress=5)
        update(job, status="done", progress=100, message="¡Clips re-exportados!")
    except Exception as e:
        traceback.print_exc()
        update(job, status="error", message=str(e)[:800])


def rerender_clip(job: dict, index: int, burn: bool):
    try:
        src = job_dir(job["id"]) / job["source_file"]
        clip = next(c for c in job["clips"] if c["index"] == index)
        fmts = list(clip.get("renders", {}).keys()) or job["options"].get("formats", ["vertical", "horizontal"])
        for k, fmt in enumerate(fmts):
            update(job, status="rendering", progress=round(5 + 90 * k / len(fmts), 1),
                   message=f"Re-exportando clip {index} · {FORMATS[fmt]['label']}…")
            clip.setdefault("renders", {})[fmt] = render_clip(job, clip, src, fmt, burn, job["options"].get("upscale", True))
            update(job, clips=job["clips"])
        update(job, status="done", progress=100, message=f"Clip {index} re-exportado.")
    except Exception as e:
        traceback.print_exc()
        update(job, status="error", message=str(e)[:800])


# ---------------------------------------------------------------- worker
_queue: list = []
_cv = threading.Condition()


def enqueue(fn, *args):
    with _cv:
        _queue.append((fn, args))
        _cv.notify()


def _worker():
    while True:
        with _cv:
            while not _queue:
                _cv.wait()
            fn, args = _queue.pop(0)
        fn(*args)


def start_worker():
    threading.Thread(target=_worker, daemon=True).start()


def delete_job(job_id: str):
    JOBS.pop(job_id, None)
    shutil.rmtree(job_dir(job_id), ignore_errors=True)
