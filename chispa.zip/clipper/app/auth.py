"""Password protection with a signed session cookie (password from CHISPA_PASSWORD)."""
from __future__ import annotations

import hashlib
import hmac
import html
import os
import secrets
import time
from pathlib import Path
from urllib.parse import quote

from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

PASSWORD = os.environ.get("CHISPA_PASSWORD", "")
PUBLIC = os.environ.get("CHISPA_PUBLIC", "0") == "1"
if PUBLIC and not PASSWORD:
    raise SystemExit("CHISPA_PUBLIC=1 pero CHISPA_PASSWORD no está definida: me niego a arrancar en modo público sin contraseña.")
ENABLED = bool(PASSWORD)
COOKIE = "chispa_session"
MAX_AGE = 7 * 24 * 3600

_secret_file = Path(__file__).resolve().parent.parent / "data" / ".session_secret"
if not _secret_file.exists():
    _secret_file.parent.mkdir(parents=True, exist_ok=True)
    _secret_file.write_text(secrets.token_hex(32))
    os.chmod(_secret_file, 0o600)
# Secret depends on the password too, so changing the password invalidates old sessions.
SECRET = hashlib.sha256((_secret_file.read_text().strip() + "|" + PASSWORD).encode()).digest()

_fails: dict[str, list[float]] = {}


def _sign(exp: int) -> str:
    return f"{exp}.{hmac.new(SECRET, str(exp).encode(), hashlib.sha256).hexdigest()}"


def valid(token: str | None) -> bool:
    if not token or "." not in token:
        return False
    exp, sig = token.split(".", 1)
    if not exp.isdigit() or int(exp) < time.time():
        return False
    return hmac.compare_digest(_sign(int(exp)), f"{exp}.{sig}")


def client_ip(req: Request) -> str:
    return req.headers.get("cf-connecting-ip") or (req.client.host if req.client else "?")


OPEN_PATHS = {"/login", "/logout", "/favicon.ico"}


async def middleware(request: Request, call_next):
    if not ENABLED or request.url.path in OPEN_PATHS or valid(request.cookies.get(COOKIE)):
        return await call_next(request)
    if request.url.path.startswith("/api/"):
        return JSONResponse({"detail": "No autenticado"}, status_code=401)
    nxt = request.url.path + (("?" + request.url.query) if request.url.query else "")
    return RedirectResponse("/login?next=" + quote(nxt, safe=""), status_code=303)


def login_page(error: str = "", nxt: str = "/") -> HTMLResponse:
    err = f'<div class="err">{html.escape(error)}</div>' if error else ""
    return HTMLResponse(f"""<!doctype html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Chispa · Iniciar sesión</title>
<style>
body{{margin:0;min-height:100vh;display:grid;place-items:center;background:radial-gradient(900px 500px at 70% -10%,#2a1240,transparent 60%),radial-gradient(800px 500px at 0% 0%,#3a1a0a,transparent 55%),#0b0b12;color:#ececf4;font:15px/1.5 Inter,system-ui,sans-serif}}
.card{{width:min(380px,92vw);background:linear-gradient(180deg,#1a1a2a,#141420);border:1px solid #26263a;border-radius:18px;padding:28px;box-shadow:0 20px 60px #0008}}
.brand{{display:flex;align-items:center;gap:10px;font-weight:800;font-size:22px;margin-bottom:6px}}
.logo{{display:grid;place-items:center;width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#ff7a18,#ff3d77);color:#fff}}
p{{color:#8b8ba3;margin:0 0 18px}}
input{{width:100%;box-sizing:border-box;background:#0e0e18;border:1px solid #26263a;border-radius:12px;color:#ececf4;padding:14px;font-size:15px;outline:none}}
input:focus{{border-color:#ff3d77}}
button{{width:100%;margin-top:14px;border:0;border-radius:12px;padding:14px;font-size:16px;font-weight:800;color:#fff;cursor:pointer;background:linear-gradient(90deg,#ff7a18,#ff3d77 60%,#a855f7)}}
.err{{margin-bottom:12px;background:#ef444422;border:1px solid #ef444466;color:#fecaca;padding:9px 12px;border-radius:10px;font-size:14px}}
</style></head><body><form class="card" method="post" action="/login">
<div class="brand"><span class="logo">⚡</span>Chispa</div><p>Acceso privado. Introduce la contraseña para continuar.</p>{err}
<input type="hidden" name="next" value="{html.escape(nxt)}">
<input type="password" name="password" placeholder="Contraseña" autofocus required autocomplete="current-password">
<button type="submit">Entrar</button></form></body></html>""", status_code=401 if error else 200)


def safe_next(nxt: str) -> str:
    return nxt if nxt.startswith("/") and not nxt.startswith("//") else "/"


async def do_login(request: Request, password: str, nxt: str):
    ip = client_ip(request)
    now = time.time()
    recent = [t for t in _fails.get(ip, []) if now - t < 600]
    if len(recent) >= 10:
        return login_page("Demasiados intentos. Espera unos minutos.", nxt)
    if not hmac.compare_digest(password.encode(), PASSWORD.encode()):
        recent.append(now)
        _fails[ip] = recent
        import asyncio
        await asyncio.sleep(1)
        return login_page("Contraseña incorrecta.", nxt)
    _fails.pop(ip, None)
    resp = RedirectResponse(safe_next(nxt), status_code=303)
    secure = request.headers.get("x-forwarded-proto", request.url.scheme) == "https"
    resp.set_cookie(COOKIE, _sign(int(now) + MAX_AGE), max_age=MAX_AGE, httponly=True, samesite="lax", secure=secure, path="/")
    return resp
