from __future__ import annotations

import re
import time
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from . import auth
from . import pipeline as P

APP_NAME = "Chispa"
ROOT = Path(__file__).resolve().parent.parent
app = FastAPI(title=f"{APP_NAME} · clips con IA")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")
app.middleware("http")(auth.middleware)
UPLOADS = P.DATA.parent / "uploads"
UPLOADS.mkdir(parents=True, exist_ok=True)
CHUNK_MAX = 95 * 1024 * 1024  # stay under Cloudflare's 100 MB per-request limit


@app.get("/login", response_class=HTMLResponse)
def login_get(next: str = "/"):
    if not auth.ENABLED:
        return RedirectResponse("/", status_code=303)
    return auth.login_page("", auth.safe_next(next))


@app.post("/login")
async def login_post(request: Request, password: str = Form(""), next: str = Form("/")):
    if not auth.ENABLED:
        return RedirectResponse("/", status_code=303)
    return await auth.do_login(request, password, next)


@app.get("/logout")
def logout():
    r = RedirectResponse("/login", status_code=303)
    r.delete_cookie(auth.COOKIE, path="/")
    return r


# ---- chunked uploads (each request < 100 MB so it works through Cloudflare tunnels)
@app.post("/api/uploads")
def upload_init(filename: str = Form(...), size: int = Form(...)):
    uid = uuid.uuid4().hex
    (UPLOADS / uid).write_bytes(b"")
    (UPLOADS / f"{uid}.name").write_text(filename[:200])
    return {"upload_id": uid, "chunk_size": 50 * 1024 * 1024}


@app.put("/api/uploads/{uid}")
async def upload_chunk(uid: str, request: Request, offset: int = 0):
    if not re.fullmatch(r"[0-9a-f]{32}", uid) or not (UPLOADS / uid).exists():
        raise HTTPException(404, "Subida no encontrada")
    path = UPLOADS / uid
    cur = path.stat().st_size
    if offset != cur:
        if offset < cur:  # retry of an already-stored chunk: truncate to offset
            with open(path, "r+b") as f:
                f.truncate(offset)
        else:
            raise HTTPException(409, f"Offset esperado {cur}")
    n = 0
    with open(path, "ab") as f:
        async for chunk in request.stream():
            n += len(chunk)
            if n > CHUNK_MAX:
                raise HTTPException(413, "Fragmento demasiado grande")
            f.write(chunk)
    return {"received": path.stat().st_size}


@app.on_event("startup")
def _startup():
    P.load_existing()
    P.start_worker()


@app.get("/", response_class=HTMLResponse)
def index():
    return (ROOT / "static" / "index.html").read_text(encoding="utf-8")


def _opts(captions, formats, num_clips, min_len, max_len, language, upscale):
    fm = [f for f in re.split(r"[,\s]+", formats or "") if f in P.FORMATS] or ["vertical", "horizontal"]
    min_len = max(5.0, min(float(min_len), 180.0))
    max_len = max(min_len + 5, min(float(max_len), 300.0))  # default UI range 60-80 s
    return {"captions": bool(captions), "formats": fm, "num_clips": max(1, min(int(num_clips), 12)),
            "min_len": min_len, "max_len": max_len, "language": language or "auto", "upscale": bool(upscale)}


@app.post("/api/jobs")
async def create_job(
    url: str = Form(""), file: UploadFile | None = File(None), upload_id: str = Form(""),
    captions: bool = Form(False), formats: str = Form("vertical,horizontal"),
    num_clips: int = Form(7), min_len: float = Form(60), max_len: float = Form(80),
    language: str = Form("auto"), upscale: bool = Form(True),
):
    if not url.strip() and not upload_id and (file is None or not file.filename):
        raise HTTPException(400, "Sube un video o pega un enlace.")
    job_id = uuid.uuid4().hex[:10]
    d = P.job_dir(job_id)
    d.mkdir(parents=True, exist_ok=True)
    if upload_id:
        if not re.fullmatch(r"[0-9a-f]{32}", upload_id) or not (UPLOADS / upload_id).exists():
            raise HTTPException(400, "Subida no encontrada.")
        orig = (UPLOADS / f"{upload_id}.name").read_text()
        ext = Path(orig).suffix.lower() or ".mp4"
        if not re.fullmatch(r"\.[a-z0-9]{1,5}", ext):
            ext = ".mp4"
        name = "source" + ext
        (UPLOADS / upload_id).replace(d / name)
        (UPLOADS / f"{upload_id}.name").unlink(missing_ok=True)
        source = {"type": "upload", "filename": name, "original_name": orig}
        title = Path(orig).stem
    elif file is not None and file.filename:
        ext = Path(file.filename).suffix.lower() or ".mp4"
        if not re.fullmatch(r"\.[a-z0-9]{1,5}", ext):
            ext = ".mp4"
        name = "source" + ext
        with open(d / name, "wb") as f:
            while chunk := await file.read(8 * 1024 * 1024):
                f.write(chunk)
        source = {"type": "upload", "filename": name, "original_name": file.filename}
        title = Path(file.filename).stem
    else:
        u = url.strip()
        if not re.match(r"^https?://", u):
            raise HTTPException(400, "El enlace debe empezar por http:// o https://")
        source = {"type": "url", "url": u}
        title = u
    job = {"id": job_id, "title": title, "source": source, "status": "queued", "progress": 0,
           "message": "En cola…", "created_at": time.time(), "updated_at": time.time(),
           "options": _opts(captions, formats, num_clips, min_len, max_len, language, upscale), "clips": []}
    P.JOBS[job_id] = job
    P.save(job)
    P.enqueue(P.process, job)
    return P.public(job)


@app.get("/api/jobs")
def list_jobs():
    jobs = sorted(P.JOBS.values(), key=lambda j: -j["created_at"])
    return [{k: j.get(k) for k in ("id", "title", "status", "progress", "message", "created_at")} | {"n_clips": len(j.get("clips", []))} for j in jobs]


def _get(job_id: str) -> dict:
    job = P.JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "Trabajo no encontrado")
    return job


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    return P.public(_get(job_id))


@app.post("/api/jobs/{job_id}/rerender")
def rerender(job_id: str, captions: bool = Form(False), formats: str = Form("vertical,horizontal"), upscale: bool = Form(True)):
    job = _get(job_id)
    if job["status"] not in ("done", "error") or not job.get("clips"):
        raise HTTPException(409, "El trabajo aún no tiene clips para re-exportar.")
    o = _opts(captions, formats, 1, 30, 90, "auto", upscale)
    P.update(job, status="queued", message="En cola para re-exportar…", progress=0)
    P.enqueue(P.rerender, job, {"captions": o["captions"], "formats": o["formats"], "upscale": o["upscale"]})
    return P.public(job)


@app.delete("/api/jobs/{job_id}")
def delete_job(job_id: str):
    job = _get(job_id)
    if job["status"] not in ("done", "error"):
        raise HTTPException(409, "No se puede borrar mientras se procesa.")
    P.delete_job(job_id)
    return {"ok": True}


def _safe(name: str) -> str:
    s = re.sub(r"[^\w\-]+", "_", name, flags=re.UNICODE).strip("_")
    return (s or "clip")[:60]


@app.get("/media/{job_id}/{name}")
def media(job_id: str, name: str, download: int = 0):
    _get(job_id)
    if "/" in name or ".." in name or not re.fullmatch(r"[\w.\-]+", name):
        raise HTTPException(400)
    path = P.job_dir(job_id) / name
    if not path.is_file() or name.startswith("source") or name.endswith(".json"):
        raise HTTPException(404)
    media_type = {".mp4": "video/mp4", ".jpg": "image/jpeg", ".srt": "application/x-subrip"}.get(path.suffix, None)
    if download:
        job = P.JOBS[job_id]
        m = re.match(r"clip_(\d+)", name)
        label = name
        if m:
            clip = next((c for c in job["clips"] if c["index"] == int(m.group(1))), None)
            if clip:
                label = f"{int(m.group(1)):02d}_{_safe(clip['title'])}{name[len('clip_00'):]}"
        else:
            label = f"{_safe(job.get('title', 'video'))}_{name}"
        return FileResponse(path, media_type=media_type, filename=label)
    return FileResponse(path, media_type=media_type)


@app.post("/api/jobs/{job_id}/clips/{index}/rerender")
def rerender_clip(job_id: str, index: int, captions: bool = Form(False)):
    job = _get(job_id)
    if job["status"] not in ("done", "error") or not any(c["index"] == index for c in job.get("clips", [])):
        raise HTTPException(409, "Clip no disponible para re-exportar.")
    P.update(job, status="queued", message=f"En cola: clip {index}…", progress=0)
    P.enqueue(P.rerender_clip, job, index, bool(captions))
    return P.public(job)
