"""SRT and ASS (animated, word-highlight) caption generation."""
from __future__ import annotations


def _srt_ts(t: float) -> str:
    t = max(0.0, t)
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def _ass_ts(t: float) -> str:
    t = max(0.0, t)
    cs = int(round(t * 100))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def words_in_range(segments, start, end):
    """Words (shifted to clip time) inside [start, end]. Falls back to
    evenly-spread words when the transcript has no word timestamps."""
    out = []
    for s in segments:
        if s["end"] < start or s["start"] > end:
            continue
        ws = s.get("words") or []
        if not ws:
            toks = s["text"].split()
            if not toks:
                continue
            step = (s["end"] - s["start"]) / len(toks)
            ws = [{"start": s["start"] + k * step, "end": s["start"] + (k + 1) * step, "word": w} for k, w in enumerate(toks)]
        for w in ws:
            if w["end"] <= start or w["start"] >= end:
                continue
            txt = w["word"].strip()
            if txt:
                out.append({"start": max(0.0, w["start"] - start), "end": min(end, w["end"]) - start, "word": txt})
    return out


def chunk_words(words, max_words=4, max_dur=1.8):
    chunks, cur = [], []
    for w in words:
        if cur and (len(cur) >= max_words or w["end"] - cur[0]["start"] > max_dur):
            chunks.append(cur)
            cur = []
        cur.append(w)
        if w["word"][-1:] in ".?!,;:…":
            chunks.append(cur)
            cur = []
    if cur:
        chunks.append(cur)
    return chunks


def build_srt(words, max_words=8, max_dur=3.5) -> str:
    lines = []
    for k, ch in enumerate(chunk_words(words, max_words, max_dur), 1):
        text = " ".join(w["word"] for w in ch)
        end = max(ch[-1]["end"], ch[0]["start"] + 0.3)
        lines.append(f"{k}\n{_srt_ts(ch[0]['start'])} --> {_srt_ts(end)}\n{text}\n")
    return "\n".join(lines)


def _esc(t: str) -> str:
    return t.replace("\\", "\\\\").replace("{", "(").replace("}", ")")


def build_ass(words, width: int, height: int, vertical: bool) -> str:
    font_size = int(round(min(width, height) * (0.088 if vertical else 0.08)))
    margin_v = int(height * (0.22 if vertical else 0.08))
    outline = max(2, font_size // 14)
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,Poppins,{font_size},&H00FFFFFF,&H00FFFFFF,&H00000000,&H64000000,-1,0,0,0,100,100,0,0,1,{outline},{max(1, outline // 2)},2,{int(width*0.06)},{int(width*0.06)},{margin_v},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    events = []
    hi = r"{\c&H2BD9FF&\fscx108\fscy108}"   # warm yellow highlight (BGR)
    norm = r"{\c&HFFFFFF&\fscx100\fscy100}"
    for ch in chunk_words(words):
        tokens = [_esc(w["word"]).upper() for w in ch]
        for idx, w in enumerate(ch):
            st = w["start"]
            en = ch[idx + 1]["start"] if idx + 1 < len(ch) else max(w["end"], st + 0.25)
            if en <= st:
                en = st + 0.05
            parts = [(hi if k == idx else norm) + t for k, t in enumerate(tokens)]
            events.append(f"Dialogue: 0,{_ass_ts(st)},{_ass_ts(en)},Cap,,0,0,0,,{' '.join(parts)}")
    return header + "\n".join(events) + "\n"
