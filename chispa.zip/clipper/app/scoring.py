"""Heuristic "viral moment" scorer (no external LLM required).

Each candidate window (a run of consecutive transcript segments lasting
min_len..max_len seconds) is scored on:
  - hook:       does it open with a question / exclamation / hook phrase?
  - energy:     mean loudness (RMS dB) of the window vs. the whole video
  - keywords:   density of the video's most distinctive keywords (TF-IDF-like)
  - density:    words per second (fast, lively speech scores higher)
  - emotion:    exclamations, questions and emphatic words per minute
  - coherence:  starts/ends on sentence boundaries, few long silences
"""
from __future__ import annotations

import math
import re
from collections import Counter

WORD_RE = re.compile(r"[a-záéíóúñüàèìòùâêîôûçß0-9']+", re.I)

STOP = set("""
a al algo algunas algunos ante antes como con contra cual cuando de del desde donde durante e el ella ellas ellos en entre era eran es esa esas ese eso esos esta estaba estado estas este esto estos fue fueron ha han hasta hay la las le les lo los mas más me mi mis mucho muy nada ni no nos o os otra otro para pero poco por porque que qué se sea ser si sí sin sobre son su sus también te tengo tiene todo todos tu tus un una uno unos y ya yo él eh este pues entonces bueno vale así aquí ahí allí estoy está están estamos voy va van vamos hacer hace hizo puede pueden
a an the and or but if of to in on at by for with from as is are was were be been being it its this that these those i you he she we they me him her us them my your his our their not no so do does did have has had will would can could should just like um uh yeah oh okay ok really very there here what which who whom then than also about into out up down over again more most some such only own same too s t don now get got going go know think thing things gonna wanna one two
""".split())

HOOK_WORDS = set("""
secreto secretos nunca jamás siempre increíble increible verdad error errores clave importante mejor peor imagina imagínate mira escucha atención cuidado truco trucos razón razones problema solución dinero gratis nadie todos realmente honestamente sorprendente loco locura brutal
secret secrets never always incredible amazing truth mistake mistakes key important best worst imagine look listen attention careful trick tricks reason reasons problem solution money free nobody everyone honestly surprising crazy insane huge biggest why how
""".split())

QUESTION_STARTERS = set("qué que cómo como por cuál cuándo dónde quién what why how when where who which".split())


def tokenize(text: str) -> list[str]:
    return [w.lower() for w in WORD_RE.findall(text)]


def content_words(text: str) -> list[str]:
    return [w for w in tokenize(text) if w not in STOP and len(w) > 2 and not w.isdigit()]


def global_keywords(segments: list[dict], top_n: int = 40) -> dict[str, float]:
    """TF-IDF-ish keyword weights where each segment is a 'document'."""
    tf = Counter()
    df = Counter()
    for s in segments:
        words = content_words(s["text"])
        tf.update(words)
        df.update(set(words))
    n = max(1, len(segments))
    weights = {}
    for w, c in tf.items():
        if c < 2:
            continue
        idf = math.log(1 + n / (1 + df[w]))
        weights[w] = c * idf
    top = sorted(weights.items(), key=lambda kv: -kv[1])[:top_n]
    if not top:
        return {}
    mx = top[0][1]
    return {w: v / mx for w, v in top}


def hook_score(text: str) -> float:
    t = text.strip()
    if not t:
        return 0.0
    words = tokenize(t)
    s = 0.0
    if "?" in t or "¿" in t:
        s = max(s, 1.0)
    if words and words[0] in QUESTION_STARTERS:
        s = max(s, 0.8)
    if "!" in t or "¡" in t:
        s = max(s, 0.8)
    if any(w in HOOK_WORDS for w in words):
        s = max(s, 0.6)
    if any(w.isdigit() for w in words):
        s = max(s, 0.35)
    return s


def emotion_count(text: str) -> int:
    words = tokenize(text)
    return text.count("!") + text.count("?") + sum(1 for w in words if w in HOOK_WORDS)


def _minmax(vals: list[float]) -> list[float]:
    if not vals:
        return vals
    lo, hi = min(vals), max(vals)
    if hi - lo < 1e-9:
        return [0.5 for _ in vals]
    return [(v - lo) / (hi - lo) for v in vals]


SENT_END = re.compile(r"[.!?…]['\"»”)]*\s*$")


def _ends_sentence(text: str) -> bool:
    return bool(SENT_END.search(text.strip()))


def make_title(text: str, kw: dict[str, float], max_chars: int = 70) -> str:
    sentences = [s.strip() for s in re.split(r"(?<=[.!?…])\s+", text) if s.strip()]
    if not sentences:
        return "Momento destacado"
    best, best_score = sentences[0], -1.0
    for i, s in enumerate(sentences):
        words = content_words(s)
        if len(words) < 2:
            continue
        nw = len(tokenize(s))
        sc = hook_score(s) * 2 + sum(kw.get(w, 0) for w in words) / (len(words) ** 0.5) + (0.3 if i == 0 else 0) + min(1.0, nw / 8) - (0.8 if nw < 5 else 0)
        if sc > best_score:
            best, best_score = s, sc
    title = best.strip(" .,;:-…\"'«»")
    if len(title) > max_chars:
        cut = title[:max_chars].rsplit(" ", 1)[0]
        title = cut.rstrip(" ,;:") + "…"
    return title[:1].upper() + title[1:]


def select_clips(segments, duration, rms_fn, n_clips=4, min_len=60.0, max_len=80.0):
    """Try the requested range first; if segment edges can't satisfy it, relax slightly."""
    res = _select(segments, duration, rms_fn, n_clips, min_len, max_len)
    if not res and segments:  # strict range impossible -> relax a little
        relaxed = _select(segments, duration, rms_fn, n_clips, min_len * 0.85, max_len * 1.1)
        if len(relaxed) > len(res):
            res = relaxed
    if not res:
        lo, hi = min_len, max_len
        if duration < min_len * 1.5:
            lo = max(5.0, duration / (n_clips + 1)); hi = max(lo + 3, duration / 2)
        res = _energy_only(duration, rms_fn, n_clips, lo, hi)
    return res


def _select(segments, duration, rms_fn, n_clips=4, min_len=60.0, max_len=80.0):
    """Return a list of clip dicts sorted by score (desc).

    segments: [{start,end,text,words:[{start,end,word}]}]
    rms_fn(t0,t1) -> mean loudness in dB for that range.
    """
    # Adapt lengths for short videos
    if duration < min_len * 1.5:
        min_len = max(5.0, duration / (n_clips + 1))
        max_len = max(min_len + 3, duration / 2)

    segments = [s for s in segments if s["text"].strip()]
    if not segments:
        return _energy_only(duration, rms_fn, n_clips, min_len, max_len)

    kw = global_keywords(segments)
    global_db = rms_fn(0, duration)
    target = (min_len + max_len) / 2

    cands = []
    n = len(segments)
    for i in range(n):
        start = segments[i]["start"]
        start_clean = i == 0 or _ends_sentence(segments[i - 1]["text"]) or (start - segments[i - 1]["end"] > 0.7)
        text_parts = []
        for j in range(i, n):
            end = segments[j]["end"]
            dur = end - start
            text_parts.append(segments[j]["text"].strip())
            if dur > max_len:
                break
            if dur < min_len:
                continue
            text = " ".join(text_parts)
            words = tokenize(text)
            cwords = content_words(text)
            gaps = [segments[k + 1]["start"] - segments[k]["end"] for k in range(i, j)]
            long_gaps = sum(1 for g in gaps if g > 2.0)
            opening = " ".join(p for p in text_parts[:2])
            end_clean = _ends_sentence(segments[j]["text"])
            cands.append({
                "i": i, "j": j, "start": start, "end": end, "text": text,
                "hook": hook_score(opening),
                "energy": rms_fn(start, end) - global_db,
                "keywords": sum(kw.get(w, 0) for w in cwords) / max(1, len(words)) ,
                "density": len(words) / max(1.0, dur),
                "emotion": emotion_count(text) / max(1.0, dur / 60),
                "coherence": 0.45 * start_clean + 0.45 * end_clean + 0.1 * (1 - min(1, long_gaps / 2)),
                "length": 1 - min(1.0, abs(dur - target) / max(1.0, target)),
            })

    if not cands:  # segment edges can't satisfy the range
        return []

    for key in ("energy", "keywords", "density", "emotion"):
        normed = _minmax([c[key] for c in cands])
        for c, v in zip(cands, normed):
            c[key + "_n"] = v
    W = {"hook": 0.20, "energy_n": 0.18, "keywords_n": 0.20, "density_n": 0.10,
         "emotion_n": 0.08, "coherence": 0.22, "length": 0.02}
    for c in cands:
        raw = sum(c[k] * w for k, w in W.items())
        c["score"] = raw

    cands.sort(key=lambda c: -c["score"])
    chosen = []
    for c in cands:
        if all(c["end"] + 1 <= o["start"] or c["start"] >= o["end"] + 1 for o in chosen):
            chosen.append(c)
        if len(chosen) >= n_clips:
            break

    # Map raw scores to a friendly 0-100 "potencial viral" scale
    best_raw = cands[0]["score"] if cands else 1
    out = []
    for c in chosen:
        pct = int(round(55 + 44 * (c["score"] / best_raw) ** 2)) if best_raw > 0 else 50
        out.append({
            # tiny padding so words aren't cut, but never past the requested range
            "start": max(0.0, c["start"] - min(0.15, (max_len - (c["end"] - c["start"])) / 3)),
            "end": min(duration, c["end"] + max(0.0, min(0.35, (max_len - (c["end"] - c["start"])) * 2 / 3))),
            "text": c["text"],
            "title": make_title(c["text"], kw),
            "score": max(1, min(99, pct)),
            "breakdown": {k.replace("_n", ""): round(float(c[k]), 2) for k in W},
        })
    return out


def _energy_only(duration, rms_fn, n_clips, min_len, max_len):
    length = min(max_len, max(min_len, (min_len + max_len) / 2), duration)
    cands = []
    t = 0.0
    while t + length <= duration + 0.01:
        cands.append({"start": t, "end": min(duration, t + length), "e": rms_fn(t, t + length)})
        t += 5.0
    if not cands:
        cands = [{"start": 0.0, "end": duration, "e": 0.0}]
    cands.sort(key=lambda c: -c["e"])
    chosen = []
    for c in cands:
        if all(c["end"] <= o["start"] or c["start"] >= o["end"] for o in chosen):
            chosen.append(c)
        if len(chosen) >= n_clips:
            break
    ns = _minmax([c["e"] for c in chosen])
    return [{
        "start": c["start"], "end": c["end"], "text": "",
        "title": f"Momento de alta energía #{k + 1}",
        "score": int(60 + 35 * v), "breakdown": {"energy": round(v, 2)},
    } for k, (c, v) in enumerate(zip(chosen, ns))]
